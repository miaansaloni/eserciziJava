public class Partecipazione {
    
}
