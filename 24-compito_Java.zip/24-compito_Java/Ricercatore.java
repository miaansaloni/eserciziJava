public class Ricercatore {
    
}
